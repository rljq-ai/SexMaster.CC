package me.chachoox.lithium.impl.event.events.misc;

public class ShutDownEvent {
}
