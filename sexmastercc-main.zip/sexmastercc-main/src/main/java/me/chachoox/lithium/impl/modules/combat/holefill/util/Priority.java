package me.chachoox.lithium.impl.modules.combat.holefill.util;

public enum Priority {
    CLOSEST,
    FARTHEST
}
