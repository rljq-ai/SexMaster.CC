package me.chachoox.lithium.impl.event.events.movement.actions;

public class JumpEvent {
}
