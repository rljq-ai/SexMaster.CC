package me.chachoox.lithium.impl.modules.combat.aura.modes;

public enum Target {
    HEALTH,
    DISTANCE
}
