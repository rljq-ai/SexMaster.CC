package me.chachoox.lithium.api.property;

import me.chachoox.lithium.api.property.util.Bind;

public class BindProperty extends Property<Bind> {
    public BindProperty(Bind bind, String[] aliases, String description) {
        super(bind, aliases, description);
    }
}
