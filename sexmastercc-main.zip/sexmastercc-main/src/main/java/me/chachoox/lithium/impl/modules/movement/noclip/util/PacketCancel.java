package me.chachoox.lithium.impl.modules.movement.noclip.util;

public enum PacketCancel {
    FORCE,
    LIMIT,
    NONE
}
