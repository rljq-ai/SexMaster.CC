package me.chachoox.lithium.impl.modules.combat.criticals;

public enum CriticalsType {
    PACKET,
    BYPASS,
}
