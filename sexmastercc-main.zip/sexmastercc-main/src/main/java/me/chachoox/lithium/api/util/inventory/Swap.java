package me.chachoox.lithium.api.util.inventory;

public enum Swap {
    SILENT,
    ALTERNATIVE,
    NONE
}
