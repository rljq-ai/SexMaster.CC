package me.chachoox.lithium.asm.ducks;

public interface IKeyBinding {
    void setPressed(boolean pressed);
}
