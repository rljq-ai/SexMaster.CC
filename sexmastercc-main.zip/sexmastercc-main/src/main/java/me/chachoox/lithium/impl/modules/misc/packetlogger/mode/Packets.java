package me.chachoox.lithium.impl.modules.misc.packetlogger.mode;

public enum Packets {
    OUTGOING,
    INCOMING,
    BOTH
}
