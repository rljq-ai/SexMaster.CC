package me.chachoox.lithium.impl.event.events.update;

public class UpdateEvent {
}
