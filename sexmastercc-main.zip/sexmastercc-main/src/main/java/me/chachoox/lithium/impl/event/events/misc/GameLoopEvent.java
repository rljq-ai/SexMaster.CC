package me.chachoox.lithium.impl.event.events.misc;

import me.chachoox.lithium.api.event.events.Event;

public class GameLoopEvent extends Event {
}
