package me.chachoox.lithium.api.interfaces;

public interface Labeled {
    String getLabel();
}
