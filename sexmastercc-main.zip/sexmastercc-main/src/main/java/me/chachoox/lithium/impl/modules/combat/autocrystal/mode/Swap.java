package me.chachoox.lithium.impl.modules.combat.autocrystal.mode;

public enum Swap {
    NONE,
    NORMAL,
    SILENT,
    ALTERNATIVE
}
