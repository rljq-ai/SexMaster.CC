package me.chachoox.lithium.impl.modules.movement.noslow.util;

public enum AntiWebMode {
    MOTION,
    TIMER,
    NONE
}
