package me.chachoox.lithium.impl.modules.combat.aura.modes;

public enum SwordMode {
    REQUIRE,
    SWITCH,
    NONE
}
