package me.chachoox.lithium.api.util.math;

public interface Passable {
    boolean passed(long delay);

}