package me.chachoox.lithium.impl.event.events.keyboard;

import me.chachoox.lithium.api.event.events.Event;

public class ClickMiddleEvent extends Event {

}
