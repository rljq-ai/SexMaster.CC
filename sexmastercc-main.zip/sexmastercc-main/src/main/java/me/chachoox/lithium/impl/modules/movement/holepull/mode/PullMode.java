package me.chachoox.lithium.impl.modules.movement.holepull.mode;

public enum PullMode {
    PULL,
    SNAP
}
