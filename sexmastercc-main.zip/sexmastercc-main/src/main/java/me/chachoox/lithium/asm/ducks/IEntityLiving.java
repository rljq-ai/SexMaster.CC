package me.chachoox.lithium.asm.ducks;

public interface IEntityLiving {
    int getArmSwingAnim();
}
