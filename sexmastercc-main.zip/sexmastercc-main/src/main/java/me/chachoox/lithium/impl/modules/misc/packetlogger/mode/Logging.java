package me.chachoox.lithium.impl.modules.misc.packetlogger.mode;

public enum Logging {
    CHAT,
    FILE
}
