package me.chachoox.lithium.impl.modules.misc.announcer.util;

public enum Type {
    WALK,
    PLACE,
    JUMP,
    BREAK,
    EAT,
}