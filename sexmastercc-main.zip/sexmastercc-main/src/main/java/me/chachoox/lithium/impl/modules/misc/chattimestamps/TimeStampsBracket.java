package me.chachoox.lithium.impl.modules.misc.chattimestamps;

public enum TimeStampsBracket {
    NONE,
    CARET,
    BRACKET
}
