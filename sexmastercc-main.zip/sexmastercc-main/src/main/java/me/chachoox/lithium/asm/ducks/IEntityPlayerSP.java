package me.chachoox.lithium.asm.ducks;

public interface IEntityPlayerSP {
    void setLastReportedYaw(float lastReportedYaw);

    void setLastReportedPitch(float lastReportedPitch);
}