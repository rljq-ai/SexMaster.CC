package me.chachoox.lithium.api.interfaces;

import net.minecraft.client.Minecraft;

public interface Minecraftable {
    Minecraft mc = Minecraft.getMinecraft();
}
