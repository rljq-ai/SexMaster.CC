package me.chachoox.lithium.impl.gui.entity;

import net.minecraft.client.gui.GuiButton;

public class DupeButton extends GuiButton {
    public DupeButton(int buttonId, int x, int y, String buttonText) {
        super(buttonId, x, y, buttonText);
    }
}