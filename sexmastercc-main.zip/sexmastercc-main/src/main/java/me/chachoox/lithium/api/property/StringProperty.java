package me.chachoox.lithium.api.property;

public class StringProperty extends Property<String> {
    public StringProperty(String string, String[] aliases) {
        super(string, aliases);
    }
}
