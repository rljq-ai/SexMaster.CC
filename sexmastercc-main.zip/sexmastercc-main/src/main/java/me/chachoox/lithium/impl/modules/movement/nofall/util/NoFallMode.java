package me.chachoox.lithium.impl.modules.movement.nofall.util;

public enum NoFallMode {
    PACKET,
    BUCKET,
    ANTI,
}
