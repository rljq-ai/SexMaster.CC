package me.chachoox.lithium.api.event.events;

public enum Stage {
    PRE,
    POST
}
