package me.chachoox.lithium.api.util.rotation;

import net.minecraft.util.EnumFacing;
//?????????????????????????
public class FacingUtil {

    public static final EnumFacing[] VALUESNODOWN = new EnumFacing[]{
            EnumFacing.UP,
            EnumFacing.NORTH,
            EnumFacing.SOUTH,
            EnumFacing.WEST,
            EnumFacing.EAST
    };
}