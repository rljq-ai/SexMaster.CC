package me.chachoox.lithium.impl.modules.misc.visualrange.mode;

public enum VisualRangeMode {
    PRIVATE,
    PUBLIC
}
