package me.chachoox.lithium.api.util.text.font;

public class CharData {
    public int width;
    public int height;
    public int storedX;
    public int storedY;
}
