package me.chachoox.lithium.impl.event.events.render.misc;

import me.chachoox.lithium.api.event.events.Event;

public class RenderSkyEvent extends Event {
}
