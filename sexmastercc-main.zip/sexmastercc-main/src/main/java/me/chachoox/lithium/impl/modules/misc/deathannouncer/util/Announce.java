package me.chachoox.lithium.impl.modules.misc.deathannouncer.util;

public enum Announce {
    KONAS,
    PHOBOS,
    ABYSS,
    TROLLHACK,
    TROLLGOD,
    WURSTPLUS,
    AURORA,
    AUTISM,
    KAMI,
    POLLOSMOD,
    WELLPLAYED,
    PRAYER,
    POLLOS,
    NFT
}
