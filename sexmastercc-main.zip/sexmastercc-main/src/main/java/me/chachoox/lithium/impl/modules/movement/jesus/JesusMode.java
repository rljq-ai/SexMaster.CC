package me.chachoox.lithium.impl.modules.movement.jesus;

public enum JesusMode {
    SOLID,
    TRAMPOLINE,
}
