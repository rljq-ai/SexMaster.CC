package me.chachoox.lithium.impl.modules.combat.autocrystal.mode;

public enum YawStep {
    FULL,
    SEMI,
    OFF
}
