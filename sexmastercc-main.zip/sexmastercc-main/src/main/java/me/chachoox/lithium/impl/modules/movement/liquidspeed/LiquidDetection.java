package me.chachoox.lithium.impl.modules.movement.liquidspeed;

public enum LiquidDetection {
    STRICT,
    FAST
}
