package me.chachoox.lithium.impl.modules.combat.aura.util;

public enum TpsSync {
    AVERAGE,
    LATEST,
    NONE
}