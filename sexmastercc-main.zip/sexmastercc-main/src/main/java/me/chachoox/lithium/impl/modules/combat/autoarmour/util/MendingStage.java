package me.chachoox.lithium.impl.modules.combat.autoarmour.util;

public enum MendingStage {
    MENDING,
    BLOCK,
    TAKEOFF
}
