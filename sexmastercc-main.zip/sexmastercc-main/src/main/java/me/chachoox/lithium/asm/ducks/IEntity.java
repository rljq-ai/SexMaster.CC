package me.chachoox.lithium.asm.ducks;

public interface IEntity {
    boolean getIsInWeb();

}