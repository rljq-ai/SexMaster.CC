# Lithium

main authors chachoox 291k & cpv

not ratted u can check for yourself some stuff pasted and broken i dont care

published early cuz of aetra being bombed

s/o crystalpvphighlights

build it yourself or ask someone to build it
